export { default as Loading } from "./Loading";
